import os
import logging
from datetime import datetime, timedelta
import base64
import requests
from io import BytesIO
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Environment variables
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
FREEPIK_API_KEY = os.getenv('FREEPIK_API_KEY')
CHANNEL_USERNAME = os.getenv('TELEGRAM_CHANNEL')

# User data storage
user_photo_count = {}  # Format: {user_id: {'count': int, 'reset_date': datetime}}

# Constants
PHOTOS_PER_DAY = 2
FREEPIK_API_URL = "https://api.freepik.com/v1/ai/image-upscaler"

# Helper functions
async def reset_counts():
    """Reset photo counts at midnight"""
    today = datetime.now().date()
    for user_id in list(user_photo_count.keys()):
        if user_photo_count[user_id]['reset_date'].date() < today:
            user_photo_count[user_id] = {'count': 0, 'reset_date': datetime.now()}

async def check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Check if user is subscribed to the channel"""
    user_id = update.effective_user.id
    try:
        chat_member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Error checking subscription: {e}")
        return False

async def process_photo(photo_file, prompt="Enhance details and colors"):
    """Process photo using FreePik AI API"""
    try:
        # Download the photo
        photo_bytes = await photo_file.download_as_bytearray()
        
        # Convert to base64
        base64_image = base64.b64encode(photo_bytes).decode('utf-8')
        
        # Prepare API request
        headers = {
            'Content-Type': 'application/json',
            'x-freepik-api-key': FREEPIK_API_KEY
        }
        
        data = {
            'image': base64_image,
            'scale_factor': '2x',
            'optimized_for': 'portrait',
            'prompt': prompt,
            'creativity': 1,
            'hdr': 1
        }
        
        # Make API request
        response = requests.post(FREEPIK_API_URL, headers=headers, json=data)
        
        if response.status_code == 200:
            # Extract the processed image from response
            result = response.json()
            processed_image_base64 = result.get('image')
            if processed_image_base64:
                # Convert base64 back to image
                processed_image_bytes = base64.b64decode(processed_image_base64)
                return BytesIO(processed_image_bytes)
        
        logger.error(f"API Error: {response.status_code} - {response.text}")
        return None
    
    except Exception as e:
        logger.error(f"Error processing photo: {e}")
        return None

# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    
    # Create subscription check button
    keyboard = [
        [InlineKeyboardButton("Check Subscription", callback_data="check_subscription")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(
        f"Hi {user.mention_html()}! I'm a Photo Retouching Bot.\n\n"
        f"I can enhance your photos using AI technology.\n\n"
        f"You can send up to {PHOTOS_PER_DAY} photos per day for retouching.\n\n"
        f"To use me, you need to subscribe to our channel: {CHANNEL_USERNAME}\n\n"
        f"Send me a photo to get started!",
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    await update.message.reply_text(
        "Here's how to use this bot:\n\n"
        "1. Subscribe to our channel: {}\n"
        "2. Send a photo to the bot\n"
        "3. Wait for the retouched version\n\n"
        "You can send up to {} photos per day.\n\n"
        "Commands:\n"
        "/start - Start the bot\n"
        "/help - Show this help message\n"
        "/remaining - Check your remaining photos for today".format(CHANNEL_USERNAME, PHOTOS_PER_DAY)
    )

async def remaining_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Check remaining photo count for the day."""
    user_id = update.effective_user.id
    
    # Initialize user data if not exists
    if user_id not in user_photo_count:
        user_photo_count[user_id] = {'count': 0, 'reset_date': datetime.now()}
    
    # Reset count if it's a new day
    today = datetime.now().date()
    if user_photo_count[user_id]['reset_date'].date() < today:
        user_photo_count[user_id] = {'count': 0, 'reset_date': datetime.now()}
    
    remaining = PHOTOS_PER_DAY - user_photo_count[user_id]['count']
    
    await update.message.reply_text(
        f"You have {remaining} photo retouch(es) remaining for today.\n"
        f"The count will reset at midnight."
    )

# Callback query handler
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button callbacks."""
    query = update.callback_query
    await query.answer()
    
    if query.data == "check_subscription":
        is_subscribed = await check_subscription(update, context)
        
        if is_subscribed:
            await query.edit_message_text(
                text="✅ You are subscribed to our channel!\n\nYou can now send photos for retouching."
            )
        else:
            keyboard = [
                [InlineKeyboardButton("Subscribe to Channel", url=f"https://t.me/{CHANNEL_USERNAME.replace('@', '')}")],
                [InlineKeyboardButton("Check Again", callback_data="check_subscription")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text="❌ You are not subscribed to our channel yet.\n\n"
                     f"Please subscribe to {CHANNEL_USERNAME} and click 'Check Again'.",
                reply_markup=reply_markup
            )

# Message handlers
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle user photos."""
    user_id = update.effective_user.id
    
    # Check subscription
    is_subscribed = await check_subscription(update, context)
    if not is_subscribed:
        keyboard = [
            [InlineKeyboardButton("Subscribe to Channel", url=f"https://t.me/{CHANNEL_USERNAME.replace('@', '')}")],
            [InlineKeyboardButton("Check Subscription", callback_data="check_subscription")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"❌ You need to subscribe to our channel {CHANNEL_USERNAME} to use this bot.",
            reply_markup=reply_markup
        )
        return
    
    # Initialize user data if not exists
    if user_id not in user_photo_count:
        user_photo_count[user_id] = {'count': 0, 'reset_date': datetime.now()}
    
    # Reset count if it's a new day
    today = datetime.now().date()
    if user_photo_count[user_id]['reset_date'].date() < today:
        user_photo_count[user_id] = {'count': 0, 'reset_date': datetime.now()}
    
    # Check daily limit
    if user_photo_count[user_id]['count'] >= PHOTOS_PER_DAY:
        tomorrow = (datetime.now() + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        hours_remaining = int((tomorrow - datetime.now()).total_seconds() / 3600)
        
        await update.message.reply_text(
            f"❌ You've reached your daily limit of {PHOTOS_PER_DAY} photos.\n"
            f"Please try again in {hours_remaining} hours when your limit resets."
        )
        return
    
    # Process the photo
    await update.message.reply_text("🔄 Processing your photo... Please wait.")
    
    photo_file = await context.bot.get_file(update.message.photo[-1].file_id)
    processed_photo = await process_photo(photo_file)
    
    if processed_photo:
        # Increment user's photo count
        user_photo_count[user_id]['count'] += 1
        remaining = PHOTOS_PER_DAY - user_photo_count[user_id]['count']
        
        # Send the processed photo
        await update.message.reply_photo(
            photo=processed_photo,
            caption=f"✅ Here's your retouched photo!\n\nYou have {remaining} retouch(es) remaining today."
        )
    else:
        await update.message.reply_text(
            "❌ Sorry, there was an error processing your photo. Please try again later."
        )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages."""
    await update.message.reply_text(
        "Please send a photo to retouch. Use /help to see available commands."
    )

def main() -> None:
    """Start the bot."""
    # Create the Application
    application = Application.builder().token(BOT_TOKEN).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("remaining", remaining_command))
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Add message handlers
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    
    # Run the bot until the user presses Ctrl-C
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
