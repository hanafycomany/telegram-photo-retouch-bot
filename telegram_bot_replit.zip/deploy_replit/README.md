# Telegram Photo Retouching Bot

This bot allows users to retouch their photos using FreePik AI technology.

## Features

- Photo retouching using FreePik AI
- Channel subscription verification
- Daily limit of 2 photos per user

## How to Run

1. Click the "Run" button to start the bot
2. The bot will run continuously as long as this Replit is active

## Environment Variables

The following environment variables are required:

- TELEGRAM_BOT_TOKEN: Your Telegram bot token
- FREEPIK_API_KEY: Your FreePik API key
- TELEGRAM_CHANNEL: Your Telegram channel username (with @ symbol)
